<?php

/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Requests\OrderFormRequest;
use App\Order;
use App\Payments;

use App\Http\Controllers\Controller;
use Auth;
use Illuminate\Support\Facades\Input;
use Braintree_Transaction;
use Braintree_Customer;
//use Braintree_WebhookNotification;
//use Braintree_Subscription;
use Braintree_CreditCard;
use Redirect;
use Session;
use URL;
class PaymentController extends Controller {

public function __construct() {
}

public function addOrder(OrderFormRequest $request)
{           
$input = Input::all();
$merchantAccountId = $input['currency'];  

 $error = '';
    if(empty($request->get('price')) || $request->get('price') == '0')
        {
            \Session::put('error', 'Please enter a amount');
        return Redirect::to('/'); 
        }
$customer_id = $this->registerUserOnBrainTree($request->name);
    
$card_token_result = $this->getCardToken($customer_id,$input['cardNumber'],$input['cardExpiry'],$input['cardCVC']);
   
if($card_token_result->success)
{
    if(!empty($card_token_result->creditCard) && $card_token_result->creditCard->cardType == 'American Express')
    {
        \Session::put('error', 'American Express is possible to use only for Currency type USD..');
            return Redirect::to('/');
    }
$card_token = 'card_token - '.$card_token_result->creditCard->token;    
$card_type =     $card_token_result->creditCard->cardType; 
}
else {
        $card_token = '';
        $card_token_error = $card_token_result->message;
        \Session::put('error', $card_token_error);
        return Redirect::to('/');
}       
    $transction_id = '';
if(!empty($card_token)){ 
$transction_result = $this->createTransaction($card_token,$customer_id,$request->price,$merchantAccountId);
if ($transction_result->success) { 
$transaction_id = $transction_result->transaction->id;
        $payment = new Payments;
        $payment->transaction_id    = $transaction_id;
        $payment->status            = 'approved';
        $payment->customer_id         = $customer_id;
        $payment->payment_status    = 'paid';
        $payment->type              = '1';
        $payment->save(); 
    
        $order  = new Order;
        $order->name                = $request->name;
        $order->currency            = $request->currency;
        $order->price               = $request->price;
        $order->payment_id          = $payment->id;
        $order->save();  
    
    \Session::put('success', 'Payment success');
            return Redirect::to('/');
} else { 
    $transction_error = '';
$errorFound = '';
foreach ($transction_result->errors->deepAll() as $error1) {
 $transction_error .= $error1->message . "<br />";
}
        $payment = new Payment;
        $payment->transaction_id    = '';
        $payment->transaction_error = $transction_error;
        $payment->status            = 'failed';
        $payment->customer_id         = $customer_id;
        $payment->payment_status    = 'not_paid';
        $payment->type              = '1';
        $payment->save(); 
    
        $order  = new Order;
        $order->name                = $request->name;
        $order->currency            = $request->currency;
        $order->price               = $request->price;
        $order->payment_id          = $payment->id;
        $order->save();  
    \Session::put('error', $transction_error);
        return Redirect::to('/');
}

}
}
 

public function registerUserOnBrainTree($name) {
$result = Braintree_Customer::create(array(
'firstName' => $name
));
if ($result->success) {
return $result->customer->id;
} else {
$errorFound = '';
foreach ($result->errors->deepAll() as $error) {
$errorFound .= $error->message . "<br />";
}
echo $errorFound ;
}
}
 

public function getCardToken($customer_id,$cardNumber,$cardExpiry,$cardCVC)
{
$card_result = Braintree_CreditCard::create(array(
'number' => $cardNumber,
'expirationDate' => trim($cardExpiry),
'customerId' => $customer_id,
'cvv' => $cardCVC
));
  
return $card_result;    
}
 

public function createTransaction($creditCardToken,$customerId,$price,$merchantAccountId){

$result = Braintree_Transaction::sale(
[
'customerId' => $customerId,
'amount' => $price,
]
);
    return $result;
}
 
}