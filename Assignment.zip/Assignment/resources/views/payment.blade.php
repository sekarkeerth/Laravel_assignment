<html>
<head>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
    <div class="w3-container">
        @if ($message = Session::get('success'))
        <div class="w3-panel w3-green w3-display-container">
            <span onclick="this.parentElement.style.display='none'"
                    class="w3-button w3-green w3-large w3-display-topright">&times;</span>
            <p>{!! $message !!}</p>
        </div>
        <?php
Session::forget('success');
?>
       @endif

        @if ($message = Session::get('error'))
        <div class="w3-panel w3-red w3-display-container">
            <span onclick="this.parentElement.style.display='none'"
                    class="w3-button w3-red w3-large w3-display-topright">&times;</span>
            <p>{!! $message !!}</p>
        </div>
        <?php
Session::forget('error');
?>
       @endif

        <form class="w3-container w3-display-middle w3-card-4 w3-padding-16" method="POST" id="payment-form"
          action="{!! URL::to('/paypal') !!}">
          <div class="w3-container w3-teal w3-padding-16">Payment Form</div>
          {{ csrf_field() }}
          <h2 class="w3-text-blue">Order Details</h2>
         
           <label class="w3-text-blue"><b>Enter name</b></label>
          <input class="w3-input w3-border" id="name" type="text" name="name"></p>  
        <label class="w3-text-blue"><b>Select Currency</b></label>
        <select name="currency" id="currency" >
        <option value="">Select Currency</option>            
          <option value="USD">USD</option>
          <option value="EUR">EUR</option>
          <option value="THB">THB</option>
          <option value="HKD">HKD</option>
          <option value="SGD">SGD</option>
          <option value="AUD">AUD</option>    
        </select></p>  
          <label class="w3-text-blue"><b>Enter Price</b></label>
          <input class="w3-input w3-border" id="price" type="text" name="price"></p>
    <div id="Payment_details">
    <h2 class="w3-text-blue">Payment Details</h2>
<div id="cardHolderName">
<label class="w3-text-blue"><b>Enter Card Holder Name</b></label>
          <input class="w3-input w3-border"  type="text" name="cardHolderName"></p></div>
<div id="cardNumber">
<label class="w3-text-blue"><b>Enter Card Num</b></label>
          <input class="w3-input w3-border"  type="text" name="cardNumber"></p></div>
<div id="cardExpiry">
<label class="w3-text-blue"><b>Enter cardExpiry</b></label>
          <input class="w3-input w3-border"  type="text" name="cardExpiry"></p></div>
<div id="cardCVC">
<label class="w3-text-blue"><b>Enter cardCVC</b></label>
          <input class="w3-input w3-border"  type="text" name="cardCVC"></p></div>
</div>
          <button class="w3-btn w3-blue" id="button1">Pay</button>
@if(session()->has('alert-success'))
    <div class="alert alert-success">
        {{ session()->get('alert-success') }}
    </div>
@endif

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
        </form>
    </div>
</body>
</html>


<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

<script>
    $('#Payment_details').hide();
    
$('#currency').change(function(){ 
    var currency = $("#currency option:selected").val();
    if (currency == 'USD' || currency == 'EUR' || currency == 'AUD'){
        $('#Payment_details').hide();
         $('#payment-form').attr('action', 'paypal');
    }
    else 
        {
            $('#Payment_details').show();
          $('#payment-form').attr('action', 'add-order');   
        }
   
  
});

</script>